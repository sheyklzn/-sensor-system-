#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    long timestamp;
    char sensor_id[32];
    char valor[64];
} Leitura;

int comparar_desc(const void *a, const void *b) {
    Leitura *l1 = (Leitura *)a;
    Leitura *l2 = (Leitura *)b;
    return (l2->timestamp - l1->timestamp);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("Uso: %s <arquivo_entrada>\n", argv[0]);
        return 1;
    }

    FILE *fp = fopen(argv[1], "r");
    if (!fp) {
        perror("Erro ao abrir o arquivo de entrada");
        return 1;
    }

    Leitura *leituras = malloc(sizeof(Leitura) * 100000);
    int total = 0;

    while (fscanf(fp, "%ld %s %s", &leituras[total].timestamp, leituras[total].sensor_id, leituras[total].valor) == 3) {
        total++;
    }

    fclose(fp);

    // Processar por sensor
    for (int i = 0; i < total; i++) {
        int ja_processado = 0;

        for (int j = 0; j < i; j++) {
            if (strcmp(leituras[i].sensor_id, leituras[j].sensor_id) == 0) {
                ja_processado = 1;
                break;
            }
        }

        if (ja_processado) continue;

        // Coletar dados do sensor atual
        Leitura *grupo = malloc(sizeof(Leitura) * total);
        int count = 0;

        for (int j = 0; j < total; j++) {
            if (strcmp(leituras[j].sensor_id, leituras[i].sensor_id) == 0) {
                grupo[count++] = leituras[j];
            }
        }

        qsort(grupo, count, sizeof(Leitura), comparar_desc);

        char nome_arquivo[64];
        sprintf(nome_arquivo, "%s.txt", leituras[i].sensor_id);
        FILE *out = fopen(nome_arquivo, "w");

        for (int k = 0; k < count; k++) {
            fprintf(out, "%ld %s %s\n", grupo[k].timestamp, grupo[k].sensor_id, grupo[k].valor);
        }

        fclose(out);
        free(grupo);
    }

    free(leituras);
    return 0;
}
