#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct {
    long timestamp;
    char valor[64];
} Leitura;

Leitura busca_binaria_decrescente(Leitura *v, int n, long alvo) {
    int ini = 0, fim = n - 1;
    Leitura melhor = v[0];
    long menor_diff = labs(v[0].timestamp - alvo);

    while (ini <= fim) {
        int meio = (ini + fim) / 2;
        long diff = labs(v[meio].timestamp - alvo);

        if (diff < menor_diff) {
            menor_diff = diff;
            melhor = v[meio];
        }

        if (v[meio].timestamp > alvo) {
            ini = meio + 1;
        } else {
            fim = meio - 1;
        }
    }

    return melhor;
}

int main(int argc, char *argv[]) {
    if (argc < 3) {
        printf("Uso: %s <ID_SENSOR> <TIMESTAMP>\n", argv[0]);
        return 1;
    }

    char nome_arquivo[64];
    sprintf(nome_arquivo, "%s.txt", argv[1]);
    long alvo = atol(argv[2]);

    FILE *fp = fopen(nome_arquivo, "r");
    if (!fp) {
        perror("Erro ao abrir arquivo do sensor");
        return 1;
    }

    Leitura *leituras = malloc(sizeof(Leitura) * 100000);
    int total = 0;
    char sensor[32];

    while (fscanf(fp, "%ld %s %s", &leituras[total].timestamp, sensor, leituras[total].valor) == 3) {
        total++;
    }

    fclose(fp);

    Leitura resultado = busca_binaria_decrescente(leituras, total, alvo);
    printf("Leitura mais próxima:\n%ld %s\n", resultado.timestamp, resultado.valor);

    free(leituras);
    return 0;
}
