#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

long gerar_timestamp(time_t inicio, time_t fim) {
    return inicio + rand() % (fim - inicio + 1);
}

void gerar_valor(char *buffer, const char *tipo) {
    if (strcmp(tipo, "CONJ_Z") == 0) {
        sprintf(buffer, "%d", rand() % 1000);
    } else if (strcmp(tipo, "CONJ_Q") == 0) {
        sprintf(buffer, "%.2f", (rand() % 10000) / 100.0);
    } else if (strcmp(tipo, "TEXTO") == 0) {
        int len = rand() % 15 + 1;
        for (int i = 0; i < len; i++) {
            buffer[i] = 'A' + rand() % 26;
        }
        buffer[len] = '\0';
    } else if (strcmp(tipo, "BINARIO") == 0) {
        sprintf(buffer, "%s", rand() % 2 ? "true" : "false");
    }
}

int main(int argc, char *argv[]) {
    if (argc < 6 || (argc - 4) % 2 != 0) {
        printf("Uso: %s <DATA_INI: dd-mm-aaaa> <DATA_FIM: dd-mm-aaaa> <ARQUIVO_SAIDA> <SENSOR1> <TIPO1> [...]\n", argv[0]);
        return 1;
    }

    struct tm tm_ini = {0}, tm_fim = {0};
    sscanf(argv[1], "%d-%d-%d", &tm_ini.tm_mday, &tm_ini.tm_mon, &tm_ini.tm_year);
    sscanf(argv[2], "%d-%d-%d", &tm_fim.tm_mday, &tm_fim.tm_mon, &tm_fim.tm_year);
    tm_ini.tm_mon -= 1; tm_ini.tm_year -= 1900;
    tm_fim.tm_mon -= 1; tm_fim.tm_year -= 1900;

    time_t t_ini = mktime(&tm_ini);
    time_t t_fim = mktime(&tm_fim);

    if (t_ini == -1 || t_fim == -1 || t_ini >= t_fim) {
        printf("Intervalo de tempo inválido.\n");
        return 1;
    }

    srand(time(NULL));
    FILE *fp = fopen(argv[3], "w");
    if (!fp) {
        perror("Erro ao criar arquivo de saída");
        return 1;
    }

    for (int i = 4; i < argc; i += 2) {
        char *sensor = argv[i];
        char *tipo = argv[i + 1];

        for (int j = 0; j < 2000; j++) {
            long ts = gerar_timestamp(t_ini, t_fim);
            char valor[64];
            gerar_valor(valor, tipo);
            fprintf(fp, "%ld %s %s\n", ts, sensor, valor);
        }
    }

    fclose(fp);
    return 0;
}
