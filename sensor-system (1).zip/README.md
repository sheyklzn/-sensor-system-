# Sistema de Medições - Sensores Industriais

Este projeto implementa um sistema de três programas em linguagem C, voltado à organização, consulta e geração de dados de sensores usados em uma planta industrial.

## ✅ Programas

### 1. `organiza` – Organização dos Dados
- Entrada: Arquivo bruto com dados no formato `<TIMESTAMP> <ID_SENSOR> <VALOR>`
- Saída: Um arquivo `.txt` por sensor, com os dados ordenados por timestamp em **ordem decrescente**.

### 2. `consulta` – Consulta por Instante
- Entrada: Nome do sensor e timestamp desejado.
- Saída: Leitura mais próxima ao timestamp fornecido, usando busca binária.

### 3. `gerador` – Geração de Arquivo de Teste
- Entrada: Intervalo de tempo (início/fim), nome dos sensores e seus tipos de dados.
- Saída: Arquivo com 2000 leituras aleatórias por sensor.

## 🧪 Tipos de dados aceitos no gerador:

- `CONJ_Z`: Inteiros
- `CONJ_Q`: Reais (float)
- `TEXTO`: String aleatória (até 16 caracteres)
- `BINARIO`: Booleano (`true` / `false`)

## 🛠️ Compilação

```bash
make
```

## ▶️ Exemplos de execução

### Gerar arquivo de teste:

```bash
./gerador "01-01-2024" "05-01-2024" dados.txt sensor1 CONJ_Z sensor2 TEXTO
```

### Organizar dados:

```bash
./organiza dados.txt
```

### Consultar sensor:

```bash
./consulta sensor1 1704300000
```

## 🧹 Limpeza

```bash
make clean
```
